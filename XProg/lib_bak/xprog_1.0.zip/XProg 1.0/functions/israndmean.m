function Bool = israndmean(obj)
    Bool=(obj.Model.XProg.RandMean==obj.Model);
end

