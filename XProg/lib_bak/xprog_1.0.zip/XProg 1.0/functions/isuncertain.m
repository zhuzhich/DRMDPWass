function Bool = isuncertain(obj)
    Bool=(obj.Model.XProg.Uncertain==obj.Model);
end

