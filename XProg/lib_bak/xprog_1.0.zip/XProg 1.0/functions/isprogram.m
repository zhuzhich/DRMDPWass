function Bool = isprogram(obj)
    Bool=(obj.Model.XProg.Program==obj.Model);
end

