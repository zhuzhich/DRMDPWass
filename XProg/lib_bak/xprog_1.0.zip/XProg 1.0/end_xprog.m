function end_xprog

rmpath(cd);
rmpath([cd '\functions']);

end

