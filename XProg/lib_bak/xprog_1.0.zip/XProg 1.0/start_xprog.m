function start_xprog

addpath(cd);
addpath([cd '\functions']);

end

